<?php

require "views/profiles/profile.view.php";