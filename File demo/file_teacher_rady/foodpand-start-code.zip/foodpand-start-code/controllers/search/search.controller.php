<?php

require "views/search/search.view.php";