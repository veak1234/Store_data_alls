<?php
require_once 'templates/header.php';
require_once 'views/listStudentsView.php';
require_once 'templates/footer.php';