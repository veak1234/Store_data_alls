<?php
//TODO: GET all values(Gender,Name,Batch,Bio,Skill) from inputs and display the result below
?>
<link rel="stylesheet" href="css/style.css">
<div class="user-info">
    <div class="user-info-header">
        <img id="userProfile" src="" alt="">
        <h2 id="userName"></h2>
        <span>Batch - <span id="userBatch"></span><span>
    </div>
    <div class="user-info-body">
        <p id="userBio"></p>
        <div id="userSkills">
            <span class=""></span>
        </div>
    </div>
</div>