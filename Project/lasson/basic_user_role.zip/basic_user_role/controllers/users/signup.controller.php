<?php
require 'views/users/signup.view.php';