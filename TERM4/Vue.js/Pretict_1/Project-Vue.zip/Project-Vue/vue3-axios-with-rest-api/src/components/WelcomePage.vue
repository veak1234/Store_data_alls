<template>
  <div class="welcome-section text-center">
    <h1>Welcome to Our Website!</h1>
    <p class="lead">
      We are delighted to have you here. Explore our selection of fruits and
      find the perfect treat for yourself!
    </p>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>