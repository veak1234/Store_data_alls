# 09-05-2024

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```
