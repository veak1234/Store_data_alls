/**
 * The different status of a bed
 */
export enum BedStatus {
  GOOD,
  OPERATIONAL,
  BROKEN,
}
