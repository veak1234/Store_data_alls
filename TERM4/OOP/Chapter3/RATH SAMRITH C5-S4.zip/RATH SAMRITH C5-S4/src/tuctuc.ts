import { Vehicle } from "./vehicle";
export class TucTuc extends Vehicle {
  private speed: number = 130;
  private passenger: number;
  constructor(plateID: string, weight: number, passenger: number) {
    super(plateID, weight);
    this.speed = this.speed;
  }
  public getSpeed(): number {
    for (let i = 0; i < this.passenger; i++) {
      this.speed -= 5;
    }
    return this.speed;
  }
}
