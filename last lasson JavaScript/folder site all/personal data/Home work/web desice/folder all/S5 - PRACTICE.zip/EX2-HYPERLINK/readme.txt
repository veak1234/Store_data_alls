Instructions : 
   - create one page for home as index.html, market, and school inside their own folder
   - link them and add images and add content as you want.