UL Type: 
  - disc ( default)
  - square
  - circle
  - none

OL Type:
  - 1 (number by default)
  - a
  - A
  - i
  - I

OL : "start", example: start="2"