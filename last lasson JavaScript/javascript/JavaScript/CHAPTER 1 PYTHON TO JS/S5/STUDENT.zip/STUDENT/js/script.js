
// ------------------------------------------------------------------------------
//	EXERCICE 1 
// ------------------------------------------------------------------------------

/*
 You need to test an array of numbers
- The array should not empty. If empty, display on console:
				This array is empty
- To be valid, each numbers of the array shall be composed of exactly 2 digits and must be positive
- If valid, display on console:
				 Valid array
- If not valid, display on console:
				Invalid array
*/

// Input to test
let ex1-testCase1 =[]
let ex1-testCase2 =[22, 33, 4, 2]
let ex1-testCase3 =[22, 33, 44, -22]
let ex1-testCase4 =[21, 33, 44, 66]


// Write your code here



// ------------------------------------------------------------------------------
//	EXERCICE 2 
// ------------------------------------------------------------------------------

/*
We have a text composed of several words
- Convert the first character of each word to uppercase
- Add all the word to a new array
o except the word that start by letter “w”
- Console shall be display the new array that contains all those word
*/

// Input to test
let ex2-testCase1 = "hello! welcome to web programing at pnc"
let ex2-testCase2 = "him is cute girl"
let ex2-testCase3 = ""
 

// Write your code here


// ------------------------------------------------------------------------------
//	EXERCICE 3
// ------------------------------------------------------------------------------

// Input to test

let ex3-testCase1 = [2.2, 23.4, 3, 33, 10, 50, 90]
let ex3-testCase2 = [2, 1, 2, 3.45, 78.3]
let ex3-testCase3 = [2, 1, 3, 4]


// Write your code here



// ------------------------------------------------------------------------------
//	EXERCICE 4
// ------------------------------------------------------------------------------

// Input to test
let students = ["Romdul", "RomChong", "Kolap"]
let countries = ["Canada", "Cambodia", "Thai"]
let majors = ["SNA", "WEB", "Database"]

// Write your code here

