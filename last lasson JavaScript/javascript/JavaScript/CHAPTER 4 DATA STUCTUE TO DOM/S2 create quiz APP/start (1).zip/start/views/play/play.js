// CODE FOR PLAY

// TODO Add the code related to STEP 2
