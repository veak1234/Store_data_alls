function addTask(event) {
  // --------- TO HELP YOU --------------------------
  // 1- Prevent default to avoid to refresh the page
  // TODO
  // 2- Get the form inputs  information
  // TODO
  // 3- Check if task text, color, date are defined :
  //    If not defined, display a warnning        "You must fill all inputs"
  // TODO
  // 4 - If defined:
  // 4-1- Create a span for the taks name
  //    - class = "task-name"
  //    - textContent =  task text
  // TODO
  // 4-2- Create a span for the taks date
  //    - class = "task-date"
  //    - textContent =  task date
  // TODO
  // 4-3- Create a p containing the 2 spans
  // TODO
  // 4-4- the P background color is the selected color
  // TODO
  // 5 - access to div classname =  "dashboard" 
  //   - append p to div

  // 6 - clear up input on form 
    // example : document.document.getElementById("taskId").value = "";
}

// MAIN ----------------------------------------------------
const btnAddTask = document.getElementById("addTaskButton");
btnAddTask.addEventListener("click", addTask);
