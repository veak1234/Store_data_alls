// main

const number = document.querySelector("#number");
const btnGroup = document.querySelectorAll("button");
let counter = 0;
for (let btn of btnGroup) {
  btn.addEventListener("click", function (e) {
    let buttonClass = e.currentTarget.classList;
    console.log(buttonClass[1])

    // check class for increment or decrement or reset button

    // color counter
    // if counter lower than 0  the color is red
    // if counter equal to 0 the color is black
    // if counter greater than 1 the color is green

    // output
    number.textContent = counter;
  });
}
