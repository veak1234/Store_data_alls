// document.addEventListener('keyup', function(event) {
//     console.log(event.key);
// })
// document.addEventListener('mouseover', function(e) {
//     if(e.target.name=="hover"){
//         console.log("hover")
//     }
//     else if(e.target.name=="click"){
//         console.log("click")
//     }
//     else{
//         console.log("nothing")
//     }
// })


// const container = document.querySelector('.container');


// container.addEventListener('click',  function(){
//     document.body.style.background = "teal";
// })
// container.addEventListener('dblclick',  function(){
//     document.body.style.background = "orange";
// })
// container.addEventListener('mouseleave',  function(){
//     document.body.style.background = "black";
// })


// container.addEventListener('mouseover',  function(){
//     document.body.style.background = "red";
// })
// container.addEventListener('mouseout',  function(){
//     document.body.style.background = "";
// })
// container.addEventListener('mousemove',  function(event){
//     console.log("x : "+event.clientX + " " + "y : "+event.clientY)
// })



// let input = document.querySelector('input');
// input.addEventListener('focus', function() {
//     document.body.style.background = "lime";
// });
// input.addEventListener('blur', function() {
//     document.body.style.background = "orange";
// });