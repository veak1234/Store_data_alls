const hex = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, "A", "B", "C", "D", "E", "F"];

const btn = // your code here
const color = // your code here

// return the color string code like example: #f00233
function colorCode() {
   // your code here
   // call get getRandomColor
}

// return the number by random number between 0 and 16 (length of hex)
function getRandomColor() {
    // your code here
}

btn.addEventListener('click', function() {
   // your code here
   // call color code 
   // change bg
   // change color 
   // change h1 content to color code 
});

