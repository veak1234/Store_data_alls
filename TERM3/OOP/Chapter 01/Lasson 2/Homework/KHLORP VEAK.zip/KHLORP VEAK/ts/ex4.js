// Instructions:
// • The array should contain ONLY numbers
// • Add types annotation and then fix errors on the code ( if any)
var value1 = 6;
var value2 = parseFloat("12.03"); // Convert string to number using parseFloat
var values = [value1, value2]; // Annotate values as an array of numbers
// Print the sum of the 2 values
console.log(values[0] + values[1]);
