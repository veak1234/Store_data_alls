export class DateTime {
    constructor(private day: number, private month: number, private year: number, private time: number ){}
}