export enum JobCategory {
    PILOT,
    CO_PILOT,
    CHEF,
    BAGGAGE_HANDLER,
    ATTENDANT
} 