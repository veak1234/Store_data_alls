/**
 * All hospital managed diseases types
 */
export enum Disease {
  STOMACH = "STOMACH",
  CANCER = "CANCER",
  EYES =  "EYES",
  TEETH =  "TEETH",
  EAR = "EAR",
  NOSE = "NOSE"
}
