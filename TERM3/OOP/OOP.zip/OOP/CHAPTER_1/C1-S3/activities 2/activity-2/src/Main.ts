import{ A } from "./A";
import{ B } from "./B";

let testA = new A();
let testB = new B();

testA.printA();
testB.printB();
