export class A {
  printA() {
    console.log("A");
  }
}
