import{ A } from "./A";
import{ B } from "./B";

let testA = new A();
let testB = new B();
console.log(testA);

testA.printA();
testB.printB();
