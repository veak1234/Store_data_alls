export class B {
  printB() {
    console.log("B");
  }
}
