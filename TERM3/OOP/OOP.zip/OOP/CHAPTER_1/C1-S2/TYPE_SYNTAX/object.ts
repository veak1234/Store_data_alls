// Object Type 
type student = {
    name: string,
    age: number,
    class: string,
    year: number
}

let student1:student={ name: "sal", age: 19, class: "WEP A", year: 2023}
console.log(student1)


