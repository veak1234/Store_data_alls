var student1 = { name: "visal", age: 20 };
console.log(student1);
