type Student={name:string, phone:number};
let student1:Student={name:"visal", phone:1235};