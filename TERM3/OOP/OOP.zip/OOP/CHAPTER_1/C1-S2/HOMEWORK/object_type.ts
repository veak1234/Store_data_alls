let staff:{name:string, age:number}={name:"rady", age:19};     // Object type
let allStuffs:{name:string, age:number}[]=[{name:"sal", age:18}]        // Array of object