let phoneNumber:string | number= 12345;     // Can be string or number
let person:(string | number)[]=[20, "Visal"];       // Array of string or number