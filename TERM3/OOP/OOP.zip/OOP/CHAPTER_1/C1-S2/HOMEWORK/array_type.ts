let arrNum:number[]=[1,2,3,4];      // Array of number
let arrStr:string[]=["visal", "me", "you"];     // Array of string