let username:string = "Visal";
let age:number = 18;
let married:boolean= false;