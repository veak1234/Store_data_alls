let phoneNumber:number;

if (Math.random() > 0.5) {
  phoneNumber = 123;
} else {
  phoneNumber = 7167762323;
}

