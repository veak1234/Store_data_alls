let phoneNumber;
if (Math.random() > 0.5) {
    phoneNumber = 168;
}
else {
    phoneNumber = 7167762323;
}
