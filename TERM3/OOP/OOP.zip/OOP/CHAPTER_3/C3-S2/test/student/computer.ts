
export class Computer{
    name:string;
    model:string;

    constructor(name:string, model:string){
        this.name = name;
        this.model = model;
    }
}