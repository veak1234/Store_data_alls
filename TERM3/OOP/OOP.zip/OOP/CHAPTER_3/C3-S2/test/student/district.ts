
export class District{
    name:string;

    constructor(name:string){
        this.name = name;
    }
}