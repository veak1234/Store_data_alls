// TODO  :

//  1- UPdate the classes to mange
//          - a schoo has many students
//          - as school has 1 director

// 2 - Create a school with a director, and students
