class School {
  city: string;

  constructor(city: string) {
    this.city = city;
  }
}
