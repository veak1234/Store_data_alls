export class Tree {
  size: number;

  constructor(size: number) {
    this.size = size;
  }
}
