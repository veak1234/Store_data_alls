export class Date{
    date:string;
    time:string;

    constructor(date:string, time:string){
        this.date = date;
        this.time = time;
    }
}