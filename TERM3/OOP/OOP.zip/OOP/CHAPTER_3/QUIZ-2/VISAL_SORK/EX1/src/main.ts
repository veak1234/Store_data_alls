import { House } from './house';
import { Chair } from './chair';

// Create object house 
let salHouse = new House("Sal");

// Add new chair 
salHouse.addChair(1);
salHouse.addChair(2);

console.log(salHouse);
