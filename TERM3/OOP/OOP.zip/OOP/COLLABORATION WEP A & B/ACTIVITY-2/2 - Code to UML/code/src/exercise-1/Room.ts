export class Room {
  rommId: string;

  constructor(rommId: string) {
    this.rommId = rommId;
  }
}
