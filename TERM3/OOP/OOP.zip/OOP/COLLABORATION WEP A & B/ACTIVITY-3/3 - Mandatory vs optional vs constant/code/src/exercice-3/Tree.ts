//
// USE CASE :
//    - Trees are ALWAYS green, we dont want the user to change their color
//
//  TODO
//    - Complete this class with the right constructor and setters method to full fill withh the sue case requirements

export class Tree {
  readonly color: string = "green";   // readonly : we cannot assign the color.

  constructor() {}
}
