
export abstract class Mail {
    constructor(private title : string, private body : string){};

}