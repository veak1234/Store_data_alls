export abstract class Drink{
    
    constructor(protected name: string, protected price : number){};

}