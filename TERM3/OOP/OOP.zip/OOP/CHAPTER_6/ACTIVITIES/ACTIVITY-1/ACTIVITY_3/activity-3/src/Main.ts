import { ColoredPoint } from "./ColoredPoint";

let p1 = new ColoredPoint(0, 20);
console.log(p1.getColor());

let p2 = new ColoredPoint(10, 0);
console.log(p2.getColor());

let p3 = new ColoredPoint(10, 20);
console.log(p3.getColor());
