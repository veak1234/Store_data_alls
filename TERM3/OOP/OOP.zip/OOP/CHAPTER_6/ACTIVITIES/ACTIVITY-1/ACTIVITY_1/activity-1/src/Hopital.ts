import { Person } from "./Person";
import { Doctor } from "./Doctor";
import { Employee } from "./Employee";
import { Manager } from "./Manager";

let newManager : Manager = new Manager("sal", "BTB", "10 Oct", 500, "IT");
console.log(newManager);

