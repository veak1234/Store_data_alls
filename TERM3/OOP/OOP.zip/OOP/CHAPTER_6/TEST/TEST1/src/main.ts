import { Person } from './person';
import { Employee } from './employee';
import { Doctor } from './doctor';
import { Manager } from './manager';


let newEmployee : Employee = new Employee("sal", "pp", "23 Oct", 200);
console.log(newEmployee.getName);
