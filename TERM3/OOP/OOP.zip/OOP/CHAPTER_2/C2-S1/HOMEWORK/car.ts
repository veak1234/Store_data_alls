export class Car{
    name:string;
    price:number;
    color:string;

    constructor(name:string,price:number,color:string){
        this.name = name;
        this.price = price;
        this.color = color;
    }
}