import { Student } from './student';

let st1:Student = new Student("Visal");
let st2:Student = new Student("Sal");

console.log(st1.isEqual(st1, st2));


