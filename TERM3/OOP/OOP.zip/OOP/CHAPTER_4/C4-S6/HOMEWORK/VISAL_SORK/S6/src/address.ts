export class Address {
    constructor(public city: string, public street : string, public country : string){}
}