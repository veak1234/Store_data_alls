class Table{
    name:string;
    computers: Computer[] = []

    constructor(name:string){
        this.name = name
    }

    addComputer(numberOfComputer:number):void{
        let result = new ()
    }
}

class Computer{
    
}