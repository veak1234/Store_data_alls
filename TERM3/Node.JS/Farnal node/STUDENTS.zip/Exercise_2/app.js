const express = require('express');
const { v4: uuidv4 } = require('uuid');
const app = express();
const port = 3000;
app.use(express.json());
app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
});
app.get('/', (req, res) => {
   // TODO
})
/**
 * Description: CRUD posts
 * Endpoint: /api/posts
 */

// Get posts
app.get('/api/posts', (req, res) => {
   // TODO
});

// Get post
app.get('/api/posts/:id', (req, res) => {
    // TODO
});

// Create a new post
app.post('/api/posts', (req, res) => {
    // TODO
});

// Delete post
app.delete('/api/posts/:id', (req, res) => {
    // TODO
})

// Update a post
app.put('/api/posts/:id', (req, res) => {
    // TODO
});