const container = document.querySelector('#container');
function getUsers(res) {
   // TODO
}

// TODO with axios.get() ...