<?php
define('MAILHOST', 'smtp.gmail.com');
define('MAILPORT', 465);
define('USERNAME', 'your_email@gmail.com');
define('MAILPASS', 'your_password');
define('SEND_FROM', 'send_from@gmail.com');
define('SEND_FROM_NAME', 'send_from@gmail.com');