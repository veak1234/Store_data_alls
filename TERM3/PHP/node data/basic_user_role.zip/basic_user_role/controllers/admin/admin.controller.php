<?php
require 'database/database.php';
require 'models/user.model.php';
require 'views/admin/admin.view.php';