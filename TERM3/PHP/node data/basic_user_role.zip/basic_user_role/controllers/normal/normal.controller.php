<?php
require "views/normal/normal.view.php";