<div class="container">
    <h1>About Page</h1>
    <img src="assets/images/1.jpg" alt="" class="img-fluid" width="400">
</div>