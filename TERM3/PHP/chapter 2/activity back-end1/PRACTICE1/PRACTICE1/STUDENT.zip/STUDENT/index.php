
<?php 
// include of header
 
//  Get value from URL here

//  include of footer 





